"Novellaw One Page Business WordPress Theme" By ThemeHunk.

== Theme: Novellaw ==

* By ThemeHunk, http://themehunk.com/

== Theme License & Copyright ==
Novellaw Theme is distributed under the terms of the GNU GPL
Novellaw Theme - Copyright 2014 Novellaw Theme, themehunk.com

License for images:
1. Image Name: main.jpg 
Resource link: https://www.pexels.com/photo/people-new-york-train-crowd-6563/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/

	
== Theme License & Copyright ==
Novellaw is distributed under the terms of the GNU GPL
Novellaw -Copyright 2016 Novellaw, ThemeHunk.com
Once again, thank you so much for trying the Novellaw WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on ThemeHunk, we would recommend you to visit the ThemeHunk Support Forum and ask your queries there.