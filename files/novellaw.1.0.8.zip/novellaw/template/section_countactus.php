<?php
$contactus_shortcode = get_theme_mod('cf_shtcd_','[lead-form form-id=1 title=Contact Us]');
?>
<?php if (get_theme_mod('cf_image','') != '') { ?>
<section id="section5" class="contact_section" style="background: url(<?php echo esc_url(
    get_theme_mod('cf_image','')); ?>) center repeat fixed;">
    <?php } else { ?>
    <section id="section5" class="contact_section">
        <?php } ?>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <?php if (get_theme_mod('cf_head_','') != '') { ?>
                    <h2 class="section-heading"><?php echo esc_html(get_theme_mod('cf_head_','')); ?></h2>
                    <?php } else { ?>
                    <h2 class="section-heading"><?php _e('Contact Us','novellaw'); ?></h2>
                    <?php } ?>
                    <?php if (get_theme_mod('cf_desc_','') != '') { ?>
                    <h3 class="section-subheading text-muted contact"><?php echo esc_html(get_theme_mod('cf_desc_','')); ?></h3>
                    <?php } else { ?>
                    <h3 class="section-subheading text-muted contact"><?php _e('Please Submit Form','novellaw'); ?></h3>
                    <?php } ?>
                </div>
            </div>
            <div class="row">
            <div class="cnt-div">
                <?php echo do_shortcode($contactus_shortcode); ?>
            </div>
            </div>
        </div>
        <div class="map">
            <?php
            $map = get_theme_mod('map_address');
            if($map !=''){
            echo html_entity_decode($map);
            } else {
            ?>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d693641.5842893864!2d-115.16196787386718!3d36.13731406778607!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80beb782a4f57dd1%3A0x3accd5e6d5b379a3!2sLas+Vegas%2C+NV%2C+USA!5e0!3m2!1sen!2sin!4v1476822133003" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            <?php } ?>
        </div>
    </section>