<div class="col-md-3 col-sm-4">
    <div class="sidebar-box main-sidebar ">
        <?php
        if (is_active_sidebar('sidebar-1')) {
            dynamic_sidebar('sidebar-1');
        }
        ?>
    </div>
</div>