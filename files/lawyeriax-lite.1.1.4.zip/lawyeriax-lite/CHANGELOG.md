
### 1.1.4 - 15/03/2017
**Changes:** 
- Fixed translations issues with WPML

### 1.1.3 - 02/03/2017
**Changes:** 
- Fixed translations issues with Polylang

### 1.1.2 - 31/01/2017
**Changes:** 
- Update tgmp to fix wprog errors

### 1.1.1 - 31/01/2017
**Changes:** 
- Fixed issue with latest news and case studies sections category selector
- Added wpml-config.xml file fro Polylang compatibility
- Fixed layout issues

### 1.0.5 - 09/09/2016
**Changes:** 
- Update fontawesome with new icons
- Improve layout for search widgets in sidebar and footer
- Fixed issue with uploading logo at certain dimensions
- Fixed author link in Latest news section and Case studies section

### 1.0.4 - 24/08/2016
**Changes:** 
- Made top navbar phone/email links clickable
- Fixed issue with missing gavel icon
- Fixed issue with HTML tags not allowed on frontpage sections

### 1.0.3 - 29/07/2016
**Changes:** 
- Fixed issue with repeater
- Fixed issue with apostrophes being escaped in output

### 1.0.2 - 22/07/2016
**Changes:** 
- Allow HTML content in frontpage sections
- Added a blog template
- Fixed issue with footer contact form in Safari
- Updated tags

### 1.0.1 - 24/05/2016
**Changes:** 
- Development
 ### 1.0.0 - 29/04/2016 Changes: lawyeriax Merge pull request #66 from cristian-ungureanu/development !!! #7 - added missing parentheses lawyeriax Fixed #55 Width page issue on mobile lawyeriax Fixed #51 Non-breaking text issue lawyeriax Fixed #56 Header overlaps page title lawyeriax Fixed #61 Testimonial arraow issue on ie9 lawyeriax Fixed #60 Search form height on sidebar on IE lawyeriax Fixed #70 Typo in style ### 1.0.0 - 25/04/2016 Changes: lawyeriax Merge pull request #47 from cristian-ungureanu/development Development lawyeriax Update README.md ### 1.0.0 - 20/04/2016 Changes: lawyeriax Lawyers page lawyeriax Resolved header issue lawyeriax Fixed #1 Centered image on mobile lawyeriax Fixed #2 Removed big padding-top of page on mobile lawyeriax Fixed #3 Added styling for feature box lawyeriax Fixed #18 Navbar size changes on scroll lawyeriax Merge pull request #25 from abaicus/development Development lawyeriax Fixed #26 Testimonial section images position lawyeriax Fixed #29 Added popup contact form lawyeriax Fixed #22 Contact us form on page lawyeriax Fixed #30 Normalize Bootstrap carousel slide heights lawyeriax Fixed #21 Pirate forms integration lawyeriax Fixed #31 Menu issue on ie lawyeriax Fixed #28 Style contact widget according to initial design lawyeriax Update readme.txt lawyeriax Update style.css
